#ifndef _DCON_H_
#define _DCON_H_

HANDLE hCon;
void OpenConsole(void){
	if(hCon==NULL){ 
		AllocConsole();  
		hCon=GetStdHandle(STD_OUTPUT_HANDLE);
	}
}
void ConsoleOut(string str){
	long unsigned ccnt;
	WriteConsole(hCon,str.c_str(),str.size(),&ccnt,NULL);
	UNUSED(ccnt);
}
int cprintf(const char *fmt,...){
	va_list vl;
	char out[STRLENMX]={""};
	int ret;
	va_start(vl,fmt);
	ret=vsprintf(out,fmt,vl);
	ConsoleOut(out);
	return ret;
}

#endif

#ifndef _DGUI_H_
#define _DGUI_H_

#include "dincludes.h"
namespace dgui{
	#include "ddef.h"
	#include "dmath.h"
	#include "dcon.h"
	#include "dbasic.h"
	#include "duser.h"
}

#endif

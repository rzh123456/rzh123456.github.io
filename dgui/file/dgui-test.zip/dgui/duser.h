#ifndef _DGUI_DUSER_H_
#define _DGUI_DUSER_H_

#define makePRFunId(name) ____DevGUI___Pre_Run____dgui_temp_vars_functions__the_name_is__##name##_____this_is_part_of_an_initializer_______DGUI___DO_NOT_USE_THIS_NAME___0_____
#define makePRVarId(name) ____DevGUI___Pre_Run____dgui_temp_vars_variables__the_name_is__##name##_____this_is_part_of_an_initializer_______DGUI___DO_NOT_USE_THIS_NAME___0_____
#define pre_run(name,fun) char makePRFunId(name)(){fun;return 0;}char makePRVarId(name)=makePRFunId(name)()

map<string,COLORREF> cols;
void initcols(void){
	cols["red"]=RGB(255,0,0);
	cols["lime"]=RGB(0,255,0);
	cols["blue"]=RGB(0,0,255);
	cols["green"]=RGB(0,128,0);
	cols["yellow"]=RGB(255,255,0);
	cols["pink"]=RGB(255,0,255);
	cols["dark purple"]=RGB(128,0,128);
	cols["purple"]=RGB(128,0,255);
	cols["aqua"]=RGB(0,255,255);
	cols["sky"]=RGB(128,255,255);
	cols["sky blue"]=RGB(128,255,255);
}
void init_duser(){
	initcols();
}
/*int stringLen(){
	GetTextExtentPoint32();
}*/
template <typename T>
void dswap(T &a,T &b){
	T tmp=a;
	a=b;
	b=tmp; 
}
void setup(int x,int y,int w,int h,string title){
	cprintf("SETUP %d %d %d %d %s\n",x,y,w,h,title.c_str());
	settitle(title);
	movewindow(x,y,w,h);
	showwindow();
}
void setup(int x,int y,int w,int h){
	setup(x,y,w,h,DefWndTitle);
}
void setup(int w,int h,string title){
	setup(DefWndX,DefWndY,w,h,title);
}
void setup(int w,int h){
	setup(DefWndX,DefWndY,w,h,DefWndTitle);
}
void setup(string title){
	ConsoleOut("SUS\n");
	setup(DefWndX,DefWndY,DefWndWidth,DefWndHeight,title);
}
void setup(void){
	setup(DefWndX,DefWndY,DefWndWidth,DefWndHeight,DefWndTitle);
}

void ellipse(int x,int y,int r1,int r2){
	DGPPELL *tmp=new DGPPELL;
	tmp->x=x,
	tmp->y=y,
	tmp->r1=r1,
	tmp->r2=r2;
	pushcmd(CMD_ELLIPSE,tmp);
}
void polygon(int len,DPOINTS pnts){
	DGPPPOLY *tmp=new DGPPPOLY;
	tmp->len=len;
	tmp->pnts=new DPOINT[len+3];
	for(int i=0;i<len;++i){
		tmp->pnts[i]=pnts[i];
	}
	pushcmd(CMD_POLY,tmp);
}
void textout(int x,int y,string txt){
	DGPPTXT *tmp=new DGPPTXT;
	tmp->x=x;
	tmp->y=y;
	tmp->txt=txt;
	pushcmd(CMD_TEXT,tmp);
}

void vppoly(int len,va_list vl){
	DPOINT *p=new DPOINT[len+3];
	for(int i=0;i<len;++i){
		p[i]=va_arg(vl,DPOINT);
	}
	polygon(len,p);
	delete[] p;
	va_end(vl);
}
void vpoly(int len,va_list vl){
	DPOINT *p=new DPOINT[len+3];
	for(int i=0;i<len;++i){
		int x=va_arg(vl,int);
		int y=va_arg(vl,int);
		p[i]=DPOINT(x,y);
	}
	polygon(len,p);
	delete[] p;
	va_end(vl);
}
void ppoly(int len,...){
	va_list vl;
	va_start(vl,len);
	vppoly(len,vl);
}
void poly(int len,...){
	va_list vl;
	va_start(vl,len);
	vpoly(len,vl);
}
void rectangle(DPOINT p1,DPOINT p2){
	int x1=p1.x,y1=p1.y,x2=p2.x,y2=p2.y;
	poly(4,x1,y1,x2,y1,x2,y2,x1,y2);
}
void rectangle(int x,int y,int a,int b){
	rectangle(DPOINT(x,y),DPOINT(x+a,y+b));
}
void circle(int x,int y,int r){
	ellipse(x,y,r,r);
}

bool keydown(int key){
	return GetAsyncKeyState(key)&0x8000;
}
DPOINT mousepos(void){
	POINT t;
	GetCursorPos(&t);
	ScreenToClient(g_hwnd,&t);
	DPOINT ret=DPOINT(t.x,t.y);
	return ret;
}
DCOLOR getRGB(int r,int g,int b){
	return RGB(r,g,b);
}
DCOLOR makecolor(string colname){
	string _="";
	int r,g,b;
	if(colname[0]=='#'){
		unsigned sz=colname.size();
		if(sz==1) return bkcol;
		if(sz<7){
			r=HexToDec255(_+colname[1]+"0"),
			g=HexToDec255(_+colname[2]+"0"),
			b=HexToDec255(_+colname[3]+"0");
			return getRGB(r,g,b);
		}
		r=HexToDec255(_+colname[1]+colname[2]),
		g=HexToDec255(_+colname[3]+colname[4]),
		b=HexToDec255(_+colname[5]+colname[6]);
		return getRGB(r,g,b);
	}
	return cols[colname];
}

//int initer=init_duser();
pre_run(init_duser,init_duser(););

#endif

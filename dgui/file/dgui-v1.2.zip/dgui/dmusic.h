#ifndef _DMUSIC_H_
#define _DMUSIC_H_

void playmusic(string path){
	PlaySound(path.c_str(),NULL,SND_FILENAME|SND_ASYNC);
}
void finishmusic(string path){
	PlaySound(path.c_str(),NULL,SND_FILENAME|SND_SYNC);
}
void playmusicuntilend(string path){
	finishmusic(path);
}
void playmusicloop(string path){
	PlaySound(path.c_str(),NULL,SND_FILENAME|SND_ASYNC|SND_LOOP);
}
void stopmusic(string path){
	PlaySound(path.c_str(),NULL,SND_FILENAME|SND_PURGE);
}
void stopallmusic(){
	PlaySound(NULL,NULL,SND_FILENAME);
}

#endif

#ifndef _DSTRING_H_
#define _DSTRING_H_

string trim(string s){
	int l=s.size();
	string ret="";
	for(int i=0;i<l;++i){
		if(!isspace(s[i])){
			ret+=s[i];
		}
	}
	return ret;
}
string trimx(string s){
	int l=s.size();
	string ret="";
	for(int i=0;i<l;++i){
		if(!isspace(s[i])){
			if(isalpha(s[i])){
				if(isupper(s[i])){
					ret+=tolower(s[i]);
				}
				else{
					ret+=s[i];
				}
			}
			else{
				ret+=s[i];
			}
		}
	}
	return ret;
}
string vstringf(string fmt,va_list vl){
	char ret[STRLENMX]={""};
	vsprintf(ret,fmt.c_str(),vl);
	return string(ret);
}
string stringf(string fmt,...){
	va_list vl;
	va_start(vl,fmt);
	return vstringf(fmt,vl);
}

#endif

#ifndef _DGUI_DUSER_H_
#define _DGUI_DUSER_H_

#define makePRFunId(name) ____DevGUI___Pre_Run____dgui_temp_vars_functions__the_name_is__##name##_____this_is_part_of_an_initializer_______DGUI___DO_NOT_USE_THIS_NAME___0_____
#define makePRVarId(name) ____DevGUI___Pre_Run____dgui_temp_vars_variables__the_name_is__##name##_____this_is_part_of_an_initializer_______DGUI___DO_NOT_USE_THIS_NAME___0_____
#define pre_run(name,fun) char makePRFunId(name)(){fun;return 0;}char makePRVarId(name)=makePRFunId(name)()

map<string,COLORREF> cols;

DCOLOR getRGB(int r,int g,int b){
	return RGB(r,g,b);
}
int getR(DCOLOR col){
	return (col&0xff);
}
int getG(DCOLOR col){
	return (col&0xff00)>>8;
}
int getB(DCOLOR col){
	return (col&0xff0000)>>16;
}
int getcolex(DCOLOR col){
	return (col&0xff000000)>>16;
}
void addcolname(string nam,DCOLOR dc){
	cols[trimx(nam)]=dc;
}
void initcols(void){
	addcolname("aqua",getRGB(0,255,255));
	addcolname("black",getRGB(0,0,0));
	addcolname("blue",getRGB(0,0,255));
	addcolname("brown",getRGB(185,122,87));
	addcolname("crimson",getRGB(220,20,60));
	addcolname("cyan",getRGB(0,255,255));
	addcolname("green",getRGB(0,128,0));
	addcolname("lime",getRGB(0,255,0));
	addcolname("orange",getRGB(255,165,0));
	addcolname("purple",getRGB(128,0,255));
	addcolname("pink",getRGB(255,192,203));
	addcolname("pink",getRGB(255,192,203));
	addcolname("red",getRGB(255,0,0));
	addcolname("teal",getRGB(0,128,128));
	addcolname("violet",getRGB(238,130,238));
	addcolname("wheat",getRGB(245,222,179));
	addcolname("white",getRGB(255,255,255));
	addcolname("yellow",getRGB(255,255,0));
	addcolname("sky",getRGB(128,255,255));
	//cols["dark purple"]=RGB(128,0,128);
	//cols["sky blue"]=RGB(128,255,255);
}
void init_duser(){
	initcols();
}
/*int stringLen(){
	GetTextExtentPoint32();
}*/
template <typename T>
void dswap(T &a,T &b){
	T tmp=a;
	a=b;
	b=tmp; 
}
void setup(int x,int y,int w,int h,string title){
	//cprintf("SETUP %d %d %d %d %s\n",x,y,w,h,title.c_str());
	Sleep(80);
	settitle(title);
	movewindow(x,y,w,h);
	movewindow(x,y,w,h);
	movewindow(x,y,w,h);
	showwindow();
}
void setup(int x,int y,int w,int h){
	setup(x,y,w,h,DefWndTitle);
}
void setup(int w,int h,string title){
	setup(DefWndX,DefWndY,w,h,title);
}
void setup(int w,int h){
	setup(DefWndX,DefWndY,w,h,DefWndTitle);
}
void setup(string title){
	//ConsoleOut("SUS\n");
	setup(DefWndX,DefWndY,DefWndWidth,DefWndHeight,title);
}
void setup(void){
	setup(DefWndX,DefWndY,DefWndWidth,DefWndHeight,DefWndTitle);
}

void ellipse(int x,int y,int r1,int r2){
	DGPPELL *tmp=new DGPPELL;
	tmp->x=x,
	tmp->y=y,
	tmp->r1=r1,
	tmp->r2=r2;
	//pushcmd(CMD_ELLIPSE,tmp);
	calldgbp(dgbp_ellipse(*tmp));
	delete tmp;
}
void polygon(int len,DPOINTS pnts){
	DGPPPOLY *tmp=new DGPPPOLY;
	tmp->len=len;
	tmp->pnts=new DPOINT[len+3];
	for(int i=0;i<len;++i){
		tmp->pnts[i]=pnts[i];
	}
	calldgbp(dgbp_poly(*tmp));
	delete tmp->pnts;
	delete tmp;
}
void textout(int x,int y,string txt){
	DGPPTXT *tmp=new DGPPTXT;
	tmp->x=x;
	tmp->y=y;
	tmp->txt=txt;
	calldgbp(dgbp_text(*tmp));
	delete tmp;
}

void vppoly(int len,va_list vl){
	DPOINT *p=new DPOINT[len+3];
	for(int i=0;i<len;++i){
		p[i]=va_arg(vl,DPOINT);
	}
	polygon(len,p);
	delete[] p;
	va_end(vl);
}
void vpoly(int len,va_list vl){
	DPOINT *p=new DPOINT[len+3];
	for(int i=0;i<len;++i){
		int x=va_arg(vl,int);
		int y=va_arg(vl,int);
		p[i]=DPOINT(x,y);
	}
	polygon(len,p);
	delete[] p;
	va_end(vl);
}
void ppoly(int len,...){
	va_list vl;
	va_start(vl,len);
	vppoly(len,vl);
}
void poly(int len,...){
	va_list vl;
	va_start(vl,len);
	vpoly(len,vl);
}
void rectangle(DPOINT p1,DPOINT p2){
	int x1=p1.x,y1=p1.y,x2=p2.x,y2=p2.y;
	poly(4,x1,y1,x2,y1,x2,y2,x1,y2);
}
void rectangle(int x,int y,int a,int b){
	rectangle(DPOINT(x,y),DPOINT(x+a,y+b));
}
void square(int x,int y,int a){
	rectangle(x,y,a,a);
}
void circle(int x,int y,int r){
	ellipse(x,y,r,r);
}
void vtextoutf(int x,int y,string fmt,va_list vl){
	char out[5007]={""};
	vsprintf(out,fmt.c_str(),vl);
	textout(x,y,out);
}
void textoutf(int x,int y,string fmt,...){
	va_list vl;
	va_start(vl,fmt);
	vtextoutf(x,y,fmt,vl);
}

bool keydown(int key){
	return GetAsyncKeyState(key)&0x8000;
}
DPOINT mousepos(void){
	POINT t;
	GetCursorPos(&t);
	ScreenToClient(g_hwnd,&t);
	DPOINT ret=DPOINT(t.x,t.y);
	return ret;
}
DCOLOR getpxcol(int x,int y){
	return (DCOLOR)GetPixel(g_hdc,x,y);
}
void setpxcol(int x,int y,DCOLOR col){
	SetPixel(g_hdc,x,y,col);
}
DCOLOR makecolor(string colname){
	string _="";
	int r,g,b;
	if(colname[0]=='#'){
		unsigned sz=colname.size();
		if(sz==1) return bkcol;
		if(sz<7){
			r=HexToDec255(_+colname[1]+"0"),
			g=HexToDec255(_+colname[2]+"0"),
			b=HexToDec255(_+colname[3]+"0");
			return getRGB(r,g,b);
		}
		r=HexToDec255(_+colname[1]+colname[2]),
		g=HexToDec255(_+colname[3]+colname[4]),
		b=HexToDec255(_+colname[5]+colname[6]);
		return getRGB(r,g,b);
	}
	return cols[trimx(colname)];
}
void setpen(int type,DCOLOR col,int wgt){
	pncol=col,
	pnwgt=wgt,
	pntype=type;
	DeleteObject(g_hpn);
	g_hpn=CreatePen(winpnstyle(pntype),pnwgt,pncol);
	SelectObject(g_hdc,g_hpn);
}
void setpentype(int type){
	setpen(type,pncol,pnwgt);
}
void setpencolor(DCOLOR col){
	setpen(pntype,col,pnwgt);
}
void setpenwidth(DCOLOR wgt){
	setpen(pntype,pncol,wgt);
}
void setfillcolor(DCOLOR col){
	brcol=col;
	DeleteObject(g_hbr);
	g_hbr=CreateSolidBrush(brcol);
	SelectObject(g_hdc,g_hbr);
}
int colordif(DCOLOR a,DCOLOR b){
	return (
		iabs(getR(a)-getR(b))+
		iabs(getG(a)-getG(b))+
		iabs(getB(a)-getB(b))
	)*100/3;
}
void fillarea(int x,int y,int tolerance=0){
	static int vst[MAXW][MAXH];
	static int dir[4][2]={{1,0},{-1,0},{0,1},{0,-1}};
	queue<DPOINT> q;
	DPOINT tmp;
	DCOLOR origin=getpxcol(x,y);
	int tx,ty;
	memset(vst,0,sizeof vst);
	q.push(DPOINT(x,y));
	setpxcol(x,y,brcol);
	vst[x][y]=1;
	while(!q.empty()){
		tmp=q.front();
		q.pop();
		for(int i=0;i<4;++i){
			tx=tmp.x+dir[i][0],
			ty=tmp.y+dir[i][1];
			if(tx<0||tx>wndw||ty<0||ty>wndh){
				continue;
			}
			if(vst[tx][ty]||colordif(origin,getpxcol(tx,ty))>tolerance){
				continue;
			}
			setpxcol(tx,ty,brcol);
			q.push(DPOINT(tx,ty));
			vst[tx][ty]=1;
		}
	}
}

void loadbmp(BMP &buf,string path,int w,int h){
	buf.del();
	buf.path=path;
	buf.w=w;
	buf.h=h;
	buf.hbm=(HBITMAP)LoadImage(NULL,path.c_str(),IMAGE_BITMAP,w,h,LR_LOADFROMFILE);
}
void drawbmp(BMP bmp,int x,int y){
	HBITMAP hbm=bmp.hbm;
	HDC thdc=CreateCompatibleDC(g_hdc);
	SelectObject(thdc,hbm);
	BitBlt(g_hdc,x,y,bmp.w,bmp.h,thdc,0,0,SRCCOPY);
	DeleteDC(thdc);
	DeleteObject(hbm);
}

//int initer=init_duser();
pre_run(init_duser,init_duser(););

#endif

#ifndef _DGUI_H_
#define _DGUI_H_

#include "dincludes.h"
namespace dgui{
	#include "ddef.h"
	#include "dmath.h"
	#include "dstring.h"
	#include "dcon.h"
	#include "dbasic.h"
	#include "duser.h"
	#include "deffect.h"
}

#ifndef _DGUI_NOUSINGNAMESPACE_
using namespace dgui;
#endif

#endif

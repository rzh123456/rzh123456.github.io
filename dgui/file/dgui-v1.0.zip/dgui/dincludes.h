#ifndef _DGUI_DINCLUDES_H_
#define _DGUI_DINCLUDES_H_

#pragma GCC optimize(3)
#pragma GCC optimize("Ofast")

#include <cstdio>
#include <cstdlib>
#include <cctype>
#include <cstring>
#include <cstdarg>
#include <cmath>
#include <process.h>
#include <vector>
#include <string>
#include <queue>
#include <map>

#include <windows.h>

using std::vector;
using std::string;
using std::queue;
using std::map;

namespace dgui{
	int WINAPI dgWinMain(HINSTANCE,HINSTANCE,LPSTR,int);
}
int WINAPI WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPSTR lpCmdLine,int nCmdShow){
	return dgui::dgWinMain(hInstance,hPrevInstance,lpCmdLine,nCmdShow); 
}

#endif
